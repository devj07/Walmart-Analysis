use walmart;
-- EXPLORATORY DATA ANALYSIS
-- How many unique cities does the data have?
SELECT 
	DISTINCT city
FROM walmart;

## There are three unique cities: Yangon, Naypyitaw and Mandalay

-- In which city is each branch?
select distinct Branch, City
from walmart;

-- How many unique product lines does the data have?
SELECT 
	DISTINCT product_line
FROM 
	walmart
ORDER BY 
	product_line ASC;
    
-- What is the most selling product line?

select  product_line,
round(sum(total),2) as total_sales,
 ROUND((SUM(total) / (SELECT SUM(total) FROM walmart) * 100), 2) AS percent_of_total_sales
 
 FROM 
    walmart
GROUP BY 
    product_line
ORDER BY 
    total_sales DESC;

-- What is the city with the largest revenue?
SELECT 
	City AS largest_revenue_city,
    ROUND(SUM(total), 2) AS total_revenue
FROM 
	walmart
GROUP BY 
	city
ORDER BY 
	total_revenue DESC
LIMIT 1;

-- What is the most common product line by gender?
SELECT 
	gender,
    product_line,
    COUNT(*) AS number_of_products
FROM
	walmart
GROUP BY 
	GENDER,
    product_line
ORDER BY 
	gender, 
    number_of_products DESC;
## Among females, Fashion accessories are popular followed by Food and beverages and Sports and travel while in males health and beauty is the popular porduct line followed by Electronic accessories and Food and beverages

    
-- What is the average rating of each product line.
SELECT 
	product_line,
    ROUND(AVG(rating), 2) AS average_rating
FROM
	walmart
GROUP BY 
	product_line
ORDER BY
	average_rating DESC;
    
-- What is the most common customer type?
SELECT 
	customer_type,
    COUNT(*) AS number_of_customers
FROM
	walmart
GROUP BY 
	customer_type;
    
# member are more
SELECT 
	gender AS most_common_gender,
    COUNT(*) AS total_customers
FROM
	walmart
GROUP BY 
	gender
ORDER BY 
	total_customers DESC
LIMIT 2;
## There are more females

-- Which time of the day do customers give most ratings?
SELECT
	Time,
    COUNT(*) AS number_of_customers
FROM
	walmart
GROUP BY 
	Time
ORDER BY
	number_of_customers DESC;
## Customers give most ratings during afternoon

-- Which time of the day do customers give most ratings per branch?
SELECT
	Branch,
    Time,
    COUNT(*) AS number_of_ratings
FROM
	walmart
GROUP BY
	Time, Branch
ORDER BY
	Branch ASC, number_of_ratings DESC;
 ## All the branches have maximum ratings during afternoon
 
 -- Which date has the best average ratings per branch?
SELECT
	Branch,
    Date,
    ROUND(AVG(rating),2) AS average_rating
FROM 
	walmart
GROUP BY 
	Branch, Date
ORDER BY 
	Branch, average_rating DESC;
    
-- Which day of the week has the best average ratings per branch?
SELECT
	Branch,
    day_name,
    ROUND(AVG(rating),2) AS average_rating
FROM 
	walmart
GROUP BY 
	Branch, day_name
ORDER BY 
	Branch, average_rating DESC;
    
## Branch A and C has the best ratings on Monday while Branch C has the best ratings on Friday


-- Number of sales made in each time of the day per weekday 
SELECT 
    sd.day_name,
    sd.time_of_day,
    sd.number_of_sales,
    (@rank := IF(@prev_day_name = sd.day_name, @rank + 1, 1)) AS ranked_sales,
    @prev_day_name := sd.day_name
FROM (
    SELECT 
        day_name,
        CASE
            WHEN `Time` BETWEEN '00:00:00' AND '11:59:59' THEN 'Morning'
            WHEN `Time` BETWEEN '12:00:00' AND '17:59:59' THEN 'Afternoon'
            WHEN `Time` BETWEEN '18:00:00' AND '23:59:59' THEN 'Evening'
            ELSE 'Other'
        END AS time_of_day,
        COUNT(*) AS number_of_sales
    FROM
        walmart
    GROUP BY
        day_name,
        time_of_day
    ORDER BY 
        day_name,
        time_of_day
) AS sd
CROSS JOIN (SELECT @rank := 0, @prev_day_name := '') AS vars;
## Entire week has predominantly maximum sales during Afternoon

-- I WANTRED TO USE THE WINDOW FUNCTION RANK,BUT THIS SERVER DOESNT SUPPORT
/*
WITH sales_daytime AS (
	SELECT 
		day_name,
		CASE
			WHEN `Time` BETWEEN '00:00:00' AND '11:59:59' THEN 'Morning'
			WHEN `Time` BETWEEN '12:00:00' AND '17:59:59' THEN 'Afternoon'
			WHEN `Time` BETWEEN '18:00:00' AND '23:59:59' THEN 'Evening'
			ELSE 'Other'
		END AS time_of_day,
		COUNT(*) AS number_of_sales
	FROM
		walmart
	GROUP BY
		day_name,
		time_of_day
	ORDER BY 
		day_name,
		time_of_day
)
SELECT
	*,
	RANK() OVER (PARTITION BY day_name ORDER BY number_of_sales DESC) AS ranked_sales
FROM
	sales_daytime;
*/

-- 1i. What is the monthly sales trend for each product line?
SELECT
    product_line,
    month_name,
    month_number,
    ROUND(SUM(Total), 2) AS total_sales,
    ROUND(SUM(Total) / SUM(SUM(Total)) OVER (PARTITION BY month_name) * 100, 2) AS sales_percent_of_total
FROM 
    walmart
GROUP BY
    product_line,
    month_name,
    month_number
ORDER BY
    product_line, total_sales DESC;
    
--  What is the distribution of payment methods across different branches and customer types?
SELECT
    branch,
    customer_type,
    payment,
    COUNT(*) AS total_transactions
FROM
    walmart
GROUP BY
    branch, customer_type, payment
ORDER BY 
	branch ASC,
    customer_type ASC,
    total_transactions DESC;
    
    --  What are the peak sales hours throughout the day?
SELECT
	time_of_day,
    COUNT(*) AS number_of_transactions
FROM
	walmart
GROUP BY 
	time_of_day
ORDER BY
	number_of_transactions DESC;
    
#afternoon is the peak hour
