show databases;

create database walmart;
use walmart;

CREATE TABLE walmart (
    InvoiceID VARCHAR(30),
    Branch VARCHAR(30),
    City VARCHAR(30),
    Customer_type VARCHAR(10),
    Gender VARCHAR(10),
    Product_line VARCHAR(30),
    Unit_price DOUBLE,
    Quantity INT,
    Tax_5pct DOUBLE,
    Total DOUBLE,
    Date DATE,
    Time TIME,
    Payment TEXT,
    COGS DOUBLE,
    Gross_income DOUBLE,
    Rating DOUBLE,
    Time_of_day TIME,
    Day_name VARCHAR(10),
    Month_name VARCHAR(10),
    Month_number VARCHAR(10),
    Year YEAR
);
SELECT `Product line` FROM `walmart`.`walmart`;

-- 1. Counting male and female seperately in each and every product line
SELECT `Product line`,
       COUNT(case when Gender = 'Male' then 1 end) AS male_count,
       COUNT(case when Gender = 'Female' then 1 end) AS female_count
FROM walmart
GROUP BY `Product line`
LIMIT 6;

-- 2
